Лічильники · peredai.com.ua — логотип «Барабан»
=================================================
Знак — віконце лічильного механізму, як на водомірі: чорні барабани — кубометри, червоний — літри, остання цифра докручується.

ios/AppIcon.appiconset/   — для Xcode: 1024 світла, темна, тонована (Contents.json уже є; iOS сама робить заокруглення)
ios/icon-composer-layers/ — шари для Apple Icon Composer (iOS 26+, «рідке скло»): 1-background, 2-window, 3-drums — перетягніть у Icon Composer,
                            вікну ввімкніть Liquid Glass, барабанам — непрозорість 100 %
ios/sizes/                — готові PNG усіх розмірів (20…1024) для інших інструментів
android/res/              — скопіюйте в app/src/main/res: адаптивна іконка (передній шар, фон, монохром для «тематичних» іконок Android 13+),
                            mipmap-*/ic_launcher.png і ic_launcher_round.png для старих Android, mipmap-anydpi-v26/ic_launcher.xml
android/play-store-512.png — іконка для Google Play (Play сам заокруглює)
web/                      — favicon.ico, favicon.svg, apple-touch-icon.png (180), icon-192/512, maskable-512, manifest.json — уже на сайті
telegram/bot-avatar-640.png — аватар бота: @BotFather → /setuserpic → оберіть бота → надішліть цей файл (Telegram обріже по колу — вікно влазить)
svg/                      — вихідні векторні файли: іконка світла/темна, малий знак, горизонтальний логотип світлий/темний

Кольори: синій #3A6BFF → ніч #0B1F6B, літри #FF3B3B, барабан #F4F6FB, цифри #12141C. Шрифт цифр — Unbounded (OFL), переведено в криві.
Згенеровано tools_logo.py (репозиторій teplo_test).
